<html>
<head>
<title> mini project</title>
<style>
body {
  background-image: url("stdium.jpg");
background-repeat: no-repeat, repeat;
background-size: cover;
}
.button {
  border: none;
  color: #b3ffd9";
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #04AA6D;
}

.button1:hover {
  background-color: #04AA6D;
  color: white;
}
</style>
<body bgcolor="#b3ffd9">


<center>
<image src="logo.jpg" height="100" width="150">

<h4><font color="#121254"> ||JAI SRI GURUDEV||</font></H4>
<h3><font color="#ccffee">Sri Adhichunchanagiri Shikshana Trust</h3></font>
<h1><font color="white">SJB INSTITUTE OF TECHNOLOGY </font></h1>
<h3><font color="#000033">(A Constituent Institution of BGS & SJB Group of Institution & Hospitals)</font></h3>
<h1><font color=" #ffff99"> Welcome to SJBIT Sports Corner</font></h1>
<a href="index.php">
<button class="button button1">Click here to know more!! </button></a>

</center>

</h1>
</body>

</html>