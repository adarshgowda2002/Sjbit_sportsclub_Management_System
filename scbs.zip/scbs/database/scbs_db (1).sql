-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2024 at 01:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scbs_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_list`
--

CREATE TABLE `booking_list` (
  `id` int(30) NOT NULL,
  `ref_code` varchar(100) NOT NULL,
  `client_id` int(30) NOT NULL,
  `facility_id` int(30) NOT NULL,
  `date_from` date NOT NULL,
  `start_time` time NOT NULL,
  `date_to` date NOT NULL,
  `end_time` time NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT 0 COMMENT '0 = Pending,\r\n1 = Confirmed,\r\n2 = Done,\r\n3 = Cancelled',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_list`
--

INSERT INTO `booking_list` (`id`, `ref_code`, `client_id`, `facility_id`, `date_from`, `start_time`, `date_to`, `end_time`, `status`, `date_created`, `date_updated`) VALUES
(1, '202203-00001', 1, 1, '2022-03-24', '00:00:00', '2022-03-24', '00:00:00', 3, '2022-03-23 13:22:06', '2022-03-23 13:49:09'),
(2, '202203-00002', 1, 2, '2022-03-24', '00:00:00', '2022-03-25', '00:00:00', 1, '2022-03-23 13:30:40', '2022-03-23 13:49:11'),
(3, '202203-00003', 2, 4, '2022-03-24', '00:00:00', '2022-03-25', '00:00:00', 1, '2022-03-23 15:40:58', '2022-03-23 15:41:59'),
(4, '202203-00004', 2, 1, '2022-03-28', '00:00:00', '2022-03-28', '00:00:00', 3, '2022-03-23 15:41:17', '2022-03-23 15:41:26'),
(5, '202407-00001', 3, 1, '2024-07-19', '00:00:00', '2024-07-12', '00:00:00', 3, '2024-07-18 22:00:28', '2024-07-18 22:00:35'),
(6, '202407-00002', 4, 2, '2024-07-22', '00:00:00', '2024-07-23', '00:00:00', 3, '2024-07-21 23:27:48', '2024-07-22 08:59:26'),
(7, '202407-00003', 4, 1, '2024-07-23', '00:00:00', '2024-07-23', '00:00:00', 0, '2024-07-22 08:59:06', NULL),
(8, '202407-00004', 4, 1, '2024-07-23', '00:00:00', '2024-07-23', '00:00:00', 0, '2024-07-22 16:14:13', NULL),
(9, '202407-00005', 4, 1, '2024-07-23', '00:00:00', '2024-07-24', '00:00:00', 0, '2024-07-22 16:48:13', NULL),
(10, '202407-00006', 4, 1, '2024-07-23', '00:00:00', '2024-07-24', '00:00:00', 0, '2024-07-22 16:48:34', NULL),
(11, '202407-00007', 4, 1, '2024-07-22', '17:10:00', '2024-07-23', '20:10:00', 0, '2024-07-22 17:10:16', NULL),
(12, '202407-00008', 4, 7, '2024-07-23', '19:31:00', '2024-07-23', '20:34:00', 3, '2024-07-22 17:31:59', '2024-07-22 20:31:23'),
(13, '202407-00009', 4, 1, '2024-07-23', '02:25:00', '2024-07-23', '23:25:00', 0, '2024-07-22 22:25:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`id`, `name`, `description`, `delete_flag`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Basket Ball', 'Basket Ball Facility', 0, 1, '2022-03-23 10:34:53', NULL),
(2, 'Badminton', 'Badminton Court', 0, 1, '2022-03-23 10:35:12', NULL),
(3, 'Tennis Court', 'Tennis Court', 0, 1, '2022-03-23 10:35:32', NULL),
(4, 'Chess', 'Chess', 0, 1, '2022-03-23 10:35:46', '2024-07-21 22:52:01'),
(5, 'Multi gym hall', 'Multi gym hall', 0, 1, '2022-03-23 10:36:08', '2024-07-21 22:51:36'),
(6, 'Baseball', 'Baseball Field', 0, 1, '2022-03-23 10:36:42', NULL),
(7, 'Carrom', 'Carrom', 0, 1, '2022-03-23 15:26:12', '2024-07-21 22:49:57'),
(8, 'Wrestling', 'Wrestling', 1, 0, '2022-03-23 15:26:42', '2024-07-21 22:50:41');

-- --------------------------------------------------------

--
-- Table structure for table `client_list`
--

CREATE TABLE `client_list` (
  `id` int(30) NOT NULL,
  `firstname` text NOT NULL,
  `middle_name` text NOT NULL,
  `lastname` text NOT NULL,
  `gender` text NOT NULL,
  `contact` text NOT NULL,
  `address` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `image_path` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_added` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `client_list`
--

INSERT INTO `client_list` (`id`, `firstname`, `middle_name`, `lastname`, `gender`, `contact`, `address`, `email`, `password`, `image_path`, `status`, `delete_flag`, `date_created`, `date_added`) VALUES
(1, 'Mark', '', 'Male', '', '09123456789', 'Sample Address', 'mcooper@sample.com', 'c7162ff89c647f444fcaa5c635dac8c3', 'uploads/clients/1.png?v=1648008107', 1, 0, '2022-03-23 12:01:47', '2022-03-23 12:01:47'),
(2, 'Samantha', '', 'Miller', 'Male', '09456789123', 'Sample Address only', 'sam23@gmail.com', '56fafa8964024efa410773781a5f9e93', 'uploads/clients/2.png?v=1648021231', 1, 0, '2022-03-23 15:40:31', '2022-03-23 15:44:07'),
(3, 'HANMANTH', '', 'Kumbar', 'Male', '9108223748', 'Bidar', 'hanmanthk04@gmail.com', '884936bb149744d770352559b3fb3944', NULL, 1, 0, '2024-07-18 21:04:26', NULL),
(4, 'HANMANTH', '', 'Kumbar', 'Male', '9108223748', 'bangalore', 'hanmanth@gmail.com', '25d55ad283aa400af464c76d713c07ad', NULL, 1, 0, '2024-07-21 22:33:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `facility_list`
--

CREATE TABLE `facility_list` (
  `id` int(30) NOT NULL,
  `facility_code` varchar(100) NOT NULL,
  `category_id` int(30) NOT NULL,
  `image_path` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `name` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facility_list`
--

INSERT INTO `facility_list` (`id`, `facility_code`, `category_id`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`, `name`, `description`) VALUES
(1, '202203-00001', 1, 'uploads/facility/1.png?v=1648020784', 1, 0, '2022-03-23 11:07:02', '2024-07-22 17:26:35', 'Indoor Basketball Court', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Times new roman\", Arial, sans-serif; font-size: 16px;\">Basketball is a team sport where two teams of five players try to score points by throwing a ball through a hoop 10 feet high. The game was invented in 1891 by Canadian-American physical education instructor James Naismith at the International Young Men\'s Christian Association (YMCA) Training School in Springfield, Massachusetts. Naismith was tasked with creating an indoor activity to keep his gym class active during the winter and on rainy days, and came up with a game using a soccer ball and two peach baskets. The first game was played with nine players on each team, but the rules have changed over time to create the modern game of basketball. The peach baskets were replaced by metal hoops with backboards in 1906, and the game became popular in the United States within a few decades. In 1932, the International Basketball Federation (FIBA) was established in Geneva, Switzerland, and the game\'s popularity spread around the world.</p>'),
(2, '202203-00002', 3, 'uploads/facility/3.png?v=1648020799', 1, 0, '2022-03-23 11:44:34', '2024-07-21 23:42:10', 'Indoor tennis', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">Table tennis, also known as ping-pong or whiff-whaff, is a racket sport that originated in England in the late 19th century as a miniature version of lawn tennis. The game is played on a hard table divided by a net, with two or four players using small rackets to hit a lightweight ball back and forth across the table. The goal is to hit the ball over the net and make it bounce on your opponent\'s side of the table in a way that they can\'t reach or return it. The player who is successful receives one point for each time they hit the ball past their opponent.</p>'),
(4, '202203-00004', 2, 'uploads/facility/2.png?v=1648020754', 1, 0, '2022-03-23 15:28:01', '2024-07-21 23:43:53', 'Single Court for Badminton', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">A great sports for fitness, badminton is excellent for people of all ages and provides a great choice for those wanting to give a new racket sport a go. Find out all about badminton and why you should start playing.\r\n\r\nBadminton is officially the fastest of all racket sports. Players can hit the shuttlecock at speeds of up to 180mph (288kph) toward their opponent. But, it is not just all about speed; a player can expect to run up to four miles (6.4km) around the court during a match whilst having the agility to maintain energy-busting rallies.\r\n\r\nSo, whilst stamina and agility are important, certainly at a competitive level, anyone can play badminton and the sport is a popular choice for people of all ages and fitness abilities.  </p>'),
(5, '202203-00005', 7, 'uploads/facility/7.png?v=1648020754', 1, 1, '2022-03-23 15:33:48', '2024-07-21 23:38:48', 'Carrom', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">The game is fast-paced and tactical, and it requires a combination of skill, technique, and hand-eye coordination. Players also need to have good knowledge of angles, nerves, and concentration. Different regions have different rules for the game, and there are also multiple variations that can be played depending on the age of the players and how much time is available. \r\nSome theories about the origins of carrom suggest that it was invented by Indian maharajas, while others say it originated in Portugal or another region and became popular in India through their empires. The game became even more popular after World War I, and today it\'s played by around 20 million people in India. Carrom is also popular in other parts of the world, and clubs and cafes in South Asia often hold tournaments. \r\n</p>'),
(6, '202203-00003', 4, 'uploads/facility/4.png?v=1648020817', 1, 0, '2022-03-23 11:45:24', '2024-07-21 23:46:00', 'Chess', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">Chess is a strategic board game with a rich history dating back over a millennium, originating from the ancient game of chaturanga in India. Played on an 8x8 grid, it involves two players who command armies of 16 pieces each, including pawns, knights, bishops, rooks, a queen, and a king. The objective is to checkmate the opponent\'s king, placing it under an inescapable threat of capture. Known for its deep intellectual challenge and requiring foresight, strategy, and tactical skill, chess has captivated millions of enthusiasts worldwide. Governed by the International Chess Federation (FIDE), the game features a global competitive scene with prestigious tournaments and a revered tradition of grandmasters. \r\n</p>'),
(7, '202203-00003', 5, 'uploads/facility/5.png?v=1648020817', 1, 0, '2022-03-23 11:45:24', '2024-07-21 23:47:16', 'Multi Gym hall', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">A multi-gym hall is a versatile fitness facility designed to cater to a wide range of physical activities and exercise routines. Equipped with various fitness equipment such as treadmills, stationary bikes, weightlifting machines, and free weights, it provides a comprehensive environment for both strength training and cardiovascular workouts. Many multi-gym halls also offer spaces for group classes like yoga, aerobics, and spinning, fostering a sense of community and motivation among users. These facilities often include amenities such as locker rooms, showers, and sometimes even saunas or swimming pools, enhancing the overall fitness experience. By accommodating diverse fitness needs and preferences, multi-gym halls serve as inclusive hubs for health and wellness, promoting active lifestyles for people of all ages and fitness levels.</p>'),
(8, '202203-00003', 8, 'uploads/facility/8.png?v=1648020817', 1, 0, '2022-03-23 11:45:24', '2024-07-21 23:48:06', 'Wrestling', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">Wrestling is one of the oldest and most primal forms of combat sport, with origins tracing back to ancient civilizations such as Greece, Rome, and Egypt. This physically demanding sport involves two competitors engaging in a grappling contest, aiming to gain control over each other through various techniques such as throws, holds, and pins. Wrestling is characterized by its emphasis on strength, agility, technique, and strategic thinking. It is divided into different styles, the most prominent being freestyle, Greco-Roman, and folkstyle, each with its own set of rules and techniques. Governed internationally by United World Wrestling (UWW), the sport is a staple in major athletic competitions, including the Olympic Games. Celebrated for its intense physicality and the skill required, wrestling continues to be a popular and respected sport worldwide.</p>'),
(9, '202203-00003', 7, 'uploads/facility/7.png?v=1648020817', 1, 0, '2022-03-23 11:45:24', '2024-07-21 23:48:58', 'Carrom', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px;\">The game is fast-paced and tactical, and it requires a combination of skill, technique, and hand-eye coordination. Players also need to have good knowledge of angles, nerves, and concentration. Different regions have different rules for the game, and there are also multiple variations that can be played depending on the age of the players and how much time is available. \r\nSome theories about the origins of carrom suggest that it was invented by Indian maharajas, while others say it originated in Portugal or another region and became popular in India through their empires. The game became even more popular after World War I, and today it\'s played by around 20 million people in India. Carrom is also popular in other parts of the world, and clubs and cafes in South Asia often hold tournaments. </p>');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'SJBIT SPORTS CORNER'),
(6, 'short_name', 'SJB'),
(11, 'logo', 'uploads/sjblogo.png?v=1648002319'),
(13, 'user_avatar', 'uploads/systemlogo.jpg'),
(14, 'cover', 'uploads/systemlogo.png?v=1648002561');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/1624240500_avatar.png', NULL, 1, '2021-01-20 14:02:37', '2021-06-21 09:55:07'),
(10, 'Claire', 'Blake', 'cblake', '542d2760db6928e65bd10de7c16bb82c', 'uploads/avatar-10.png?v=1648021481', NULL, 2, '2022-03-23 15:44:41', '2022-03-23 15:44:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_list`
--
ALTER TABLE `booking_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cab_id` (`facility_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_list`
--
ALTER TABLE `client_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`) USING HASH;

--
-- Indexes for table `facility_list`
--
ALTER TABLE `facility_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_list`
--
ALTER TABLE `booking_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `client_list`
--
ALTER TABLE `client_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `facility_list`
--
ALTER TABLE `facility_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking_list`
--
ALTER TABLE `booking_list`
  ADD CONSTRAINT `booking_list_ibfk_1` FOREIGN KEY (`facility_id`) REFERENCES `facility_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_list_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `facility_list`
--
ALTER TABLE `facility_list`
  ADD CONSTRAINT `facility_list_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category_list` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
