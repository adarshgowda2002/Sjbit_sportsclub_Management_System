<h1 class="">Welcome to <?php echo $_settings->info('name') ?></h1>
<hr>
<style>
  #cover_img_dash{
    width:100%;
    max-height:50vh;
    object-fit:cover;
    object-position:bottom center;
  }
</style>
<div class="row">
  <!-- Existing info boxes -->
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box">
      <span class="info-box-icon bg-gradient-dark elevation-1"><i class="fas fa-copyright"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Total Categories</span>
        <span class="info-box-number">
          <?php 
            $inv = $conn->query("SELECT count(id) as total FROM category_list where delete_flag = 0 ")->fetch_assoc()['total'];
            echo number_format($inv);
          ?>
        </span>
      </div>
    </div>
  </div>
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box">
      <span class="info-box-icon bg-gradient-warning elevation-1"><i class="fas fa-door-closed"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Total Facilities</span>
        <span class="info-box-number">
          <?php 
            $inv = $conn->query("SELECT count(id) as total FROM facility_list where delete_flag = 0 ")->fetch_assoc()['total'];
            echo number_format($inv);
          ?>
        </span>
      </div>
    </div>
  </div>
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box mb-3">
      <span class="info-box-icon bg-gradient-primary elevation-1"><i class="fas fa-users"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Registered Clients</span>
        <span class="info-box-number">
          <?php 
            $mechanics = $conn->query("SELECT count(id) as total FROM client_list where delete_flag = 0 ")->fetch_assoc()['total'];
            echo number_format($mechanics);
          ?>
        </span>
      </div>
    </div>
  </div>
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box mb-3">
      <span class="info-box-icon bg-gradient-light elevation-1"><i class="fas fa-tasks"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Pending Bookings</span>
        <span class="info-box-number">
          <?php 
            $services = $conn->query("SELECT count(id) as total FROM booking_list where status = 0 ")->fetch_assoc()['total'];
            echo number_format($services);
          ?>
        </span>
      </div>
    </div>
  </div>
</div>
<hr>

<!-- Recent Registered Clients Section -->
<h2>Recent Registered Clients</h2>
<div class="recent-clients">
  <?php
    // Query for the most recent registered clients
    $recent_clients = $conn->query("SELECT * FROM client_list WHERE delete_flag = 0 ORDER BY registration_date DESC LIMIT 5");
    if ($recent_clients->num_rows > 0) {
      echo '<ul>';
      while ($client = $recent_clients->fetch_assoc()) {
        echo '<li>' . htmlspecialchars($client['name']) . ' - Registered on ' . date('Y-m-d', strtotime($client['registration_date'])) . '</li>';
      }
      echo '</ul>';
    } else {
      echo '<p>No recent clients.</p>';
    }
  ?>
</div>

<div class="text-center">
  <img src="<?= validate_image($_settings->info('cover')) ?>" alt="System Cover" class="w-100 img-fluid img-thumbnail border" id="cover_img_dash">
</div>
