<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="path/to/your/css/framework.css"> <!-- Adjust this path -->
  <style>
    /* Basic reset and layout styles */
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      display: flex;
      height: 100vh;
    }

    /* Sidebar styles */
    .main-sidebar {
      width: 250px;
      background-color: #343a40;
      color: #fff;
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow-y: auto;
      position: sticky;
      top: 0;
    }

    .brand-link {
      display: flex;
      align-items: center;
      padding: 0.5rem;
      text-decoration: none;
      color: #fff;
    }

    .brand-link img {
      margin-right: 10px;
    }

    .nav-link {
      color: #fff;
      text-decoration: none;
      padding: 0.5rem 1rem;
      display: block;
    }

    .nav-link.active {
      background-color: #007bff;
    }

    .nav-link:hover {
      background-color: #0056b3;
    }

    .content-wrapper {
      flex-grow: 1;
      padding: 1rem;
      background-color: #f4f6f9;
      overflow-y: auto;
    }

    .nav-item {
      list-style: none;
    }

    .nav-header {
      padding: 1rem;
      font-weight: bold;
      background-color: #343a40;
      color: #fff;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
      .main-sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }

      .content-wrapper {
        margin-top: 0;
      }
    }
  </style>
</head>
<body>
  <aside class="main-sidebar sidebar-dark-primary bg-gradient-dark text-light elevation-4 sidebar-no-expand">
    <!-- Brand Logo -->
    <a href="<?php echo base_url ?>admin" class="brand-link bg-gradient-primary text-sm text-light">
      <img src="<?php echo validate_image($_settings->info('logo'))?>" alt="Store Logo" class="brand-image img-circle elevation-3 bg-gradient-light" style="opacity: .8;width: 1.6rem;height: 1.6rem;max-height: unset">
      <span class="brand-text font-weight-light"><?php echo $_settings->info('short_name') ?></span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
      <nav class="mt-4">
        <ul class="nav nav-pills nav-sidebar flex-column text-sm nav-compact nav-flat nav-child-indent nav-collapse-hide-child" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item dropdown">
            <a href="./" class="nav-link nav-home">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li> 
          <li class="nav-item dropdown">
            <a href="<?php echo base_url ?>admin/?page=facilities" class="nav-link nav-facilities">
              <i class="nav-icon fas fa-door-closed"></i>
              <p>Facility List</p>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a href="<?php echo base_url ?>admin/?page=clients" class="nav-link nav-clients">
              <i class="nav-icon fas fa-users"></i>
              <p>Registered Clients</p>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a href="<?php echo base_url ?>admin/?page=bookings" class="nav-link nav-bookings">
              <i class="nav-icon fas fa-tasks"></i>
              <p>Booking List</p>
            </a>
          </li>
          <?php if($_settings->userdata('type') == 1): ?>
          <li class="nav-header">Maintenance</li>
          <li class="nav-item dropdown">
            <a href="<?php echo base_url ?>admin/?page=categories" class="nav-link nav-categories">
              <i class="nav-icon fas fa-th-list"></i>
              <p>Category List</p>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a href="<?php echo base_url ?>admin/?page=user/list" class="nav-link nav-user_list">
              <i class="nav-icon fas fa-users-cog"></i>
              <p>User List</p>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a href="<?php echo base_url ?>admin/?page=system_info" class="nav-link nav-system_info">
              <i class="nav-icon fas fa-cogs"></i>
              <p>Settings</p>
            </a>
          </li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
    <!-- /.sidebar -->
  </aside>

   <script src="path/to/jquery.js"></script> <!-- Adjust this path -->
  <script>
    $(document).ready(function(){
      var page = '<?php echo isset($_GET['page']) ? $_GET['page'] : 'home' ?>';
      var s = '<?php echo isset($_GET['s']) ? $_GET['s'] : '' ?>';
      page = page.replace('/',"_");
      if(s!='')
        page = page+'_'+s;

      if($('.nav-link.nav-'+page).length > 0){
        $('.nav-link.nav-'+page).addClass('active');
        if($('.nav-link.nav-'+page).hasClass('tree-item') == true){
          $('.nav-link.nav-'+page).closest('.nav-treeview').siblings('a').addClass('active');
          $('.nav-link.nav-'+page).closest('.nav-treeview').parent().addClass('menu-open');
        }
        if($('.nav-link.nav-'+page).hasClass('nav-is-tree') == true){
          $('.nav-link.nav-'+page).parent().addClass('menu-open');
        }
      }
    });
  </script>
</body>
</html>
